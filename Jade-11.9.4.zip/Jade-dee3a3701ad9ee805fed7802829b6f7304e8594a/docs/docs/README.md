# Preface

Welcome to Jade's developer wiki!

## Links

 - [CurseForge](https://www.curseforge.com/minecraft/mc-mods/jade)
 - [GitHub](https://github.com/Snownee/Jade)
 - [Discord](https://discord.gg/KzGQW7a)
