package snownee.jade.gui;

public interface JadeFont {

	void jade$setGlint(float glint1, float glint2);

	void jade$setGlintStrength(float glint1Strength, float glint2Strength);
}
