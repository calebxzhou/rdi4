package snownee.jade.impl.template;

import net.minecraft.resources.ResourceLocation;
import snownee.jade.api.BlockAccessor;

public final class TemplateBlockServerDataProvider extends TemplateServerDataProvider<BlockAccessor> {
	public TemplateBlockServerDataProvider(ResourceLocation uid) {
		super(uid);
	}
}
