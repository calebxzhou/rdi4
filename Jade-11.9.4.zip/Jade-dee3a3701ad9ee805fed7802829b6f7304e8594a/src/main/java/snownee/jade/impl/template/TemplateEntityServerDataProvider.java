package snownee.jade.impl.template;

import net.minecraft.resources.ResourceLocation;
import snownee.jade.api.EntityAccessor;

public final class TemplateEntityServerDataProvider extends TemplateServerDataProvider<EntityAccessor> {
	public TemplateEntityServerDataProvider(ResourceLocation uid) {
		super(uid);
	}
}
