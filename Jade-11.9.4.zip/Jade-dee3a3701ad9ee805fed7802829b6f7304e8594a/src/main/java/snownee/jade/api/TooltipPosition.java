package snownee.jade.api;

public final class TooltipPosition {
	public static final int HEAD = -10000;
	public static final int BODY = 0;
	public static final int TAIL = 10000;
}
