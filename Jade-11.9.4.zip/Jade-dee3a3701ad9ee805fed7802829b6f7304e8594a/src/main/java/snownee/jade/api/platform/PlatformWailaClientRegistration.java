package snownee.jade.api.platform;

import net.minecraft.world.level.block.Block;

public interface PlatformWailaClientRegistration {

	void registerCustomEnchantPower(Block block, CustomEnchantPower customEnchantPower);

}
