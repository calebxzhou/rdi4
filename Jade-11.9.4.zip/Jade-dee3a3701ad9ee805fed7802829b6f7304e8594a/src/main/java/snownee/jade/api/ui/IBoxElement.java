package snownee.jade.api.ui;

public interface IBoxElement extends IElement {

	ITooltipRenderer getTooltipRenderer();

}
